export interface Licenciatura {
  id: string;
  nome: string;
  area: string;
  categoria: string;
  imagem: string;
}

export interface BannerLink {
  href: string;
  top: string;
  left: string;
  width: string;
  height: string;
  label: string;
}

export interface Banner {
  image: string;
  mobileImage?: string;
  links: BannerLink[];
}
