import { motion } from 'motion/react';
import { WhatsAppIcon } from './Icons';

interface SupportCardProps {
  index: number;
  selectedFormacao: string | null;
}

export const SupportCard = ({ index, selectedFormacao }: SupportCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.02, y: -4 }}
      transition={{ 
        duration: 0.4,
        delay: index * 0.03,
        ease: "easeOut"
      }}
      className="col-span-2 md:col-span-1 group relative bg-white rounded-xl md:rounded-3xl overflow-hidden shadow-sm hover:shadow-xl border border-neutral-100 flex flex-col h-full transition-shadow duration-300"
    >
      <div className="p-4 md:p-6 flex-1 flex flex-col items-center md:items-start text-center md:text-left justify-center">
        <h3 className="text-lg md:text-[1.35rem] font-black text-neutral-900 mb-2 leading-tight tracking-tight">
          Não encontrou o curso ideal?
        </h3>
        <p className="text-neutral-500 text-[12px] md:text-sm leading-relaxed font-bold">
          Fale com nossos consultores e descubra a melhor opção
        </p>
      </div>

      <div className="p-0">
        <a 
          href={`https://api.whatsapp.com/send?phone=5511950294174&text=Olá! Sou formado em ${selectedFormacao} e quero saber sobre os cursos de Licenciatura.`}
          target="_blank"
          rel="noopener noreferrer"
          className="bg-[#25D366] text-white py-3.5 md:py-4 px-4 flex flex-col items-center justify-center gap-1.5 font-black uppercase tracking-widest text-[11px] md:text-xs hover:bg-[#128C7E] transition-all active:scale-100 w-full"
        >
          <div className="flex items-center justify-center gap-2">
            <WhatsAppIcon className="w-4 h-4 md:w-5 md:h-5 fill-current" />
            <span className="text-center leading-tight">Falar com consultor</span>
          </div>
        </a>
      </div>
    </motion.div>
  );
};
