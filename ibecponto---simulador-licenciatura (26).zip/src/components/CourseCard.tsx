import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { Licenciatura } from '../types';
import { FALLBACK_IMAGE } from '../data/constants';

interface CourseCardProps {
  curso: Licenciatura;
  index: number;
  mode: string | null;
  selectedFormacao: string | null;
}

export const CourseCard: React.FC<CourseCardProps> = ({ curso, index, mode, selectedFormacao }) => {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.02, y: -4 }}
      transition={{ 
        duration: 0.4,
        delay: index * 0.03,
        ease: "easeOut"
      }}
      className="group relative bg-white rounded-xl md:rounded-3xl overflow-hidden shadow-sm hover:shadow-xl border border-neutral-100 flex flex-col h-full transition-shadow duration-300"
    >
      <div className="relative h-24 md:h-56 overflow-hidden bg-neutral-100">
        {/* Skeleton Shimmer */}
        {!isLoaded && (
          <div className="absolute inset-0 animate-shimmer z-10" />
        )}
        
        <img 
          src={curso.imagem} 
          alt={curso.nome}
          width={400}
          height={224}
          onLoad={() => setIsLoaded(true)}
          className={`w-full h-full object-cover transition-all duration-700 group-hover:scale-110 ${
            isLoaded ? 'opacity-100' : 'opacity-0'
          }`}
          referrerPolicy="no-referrer"
          loading="lazy"
          onError={(e) => { 
            e.currentTarget.src = FALLBACK_IMAGE;
            setIsLoaded(true);
          }}
        />
        {/* Tag Área - Flutuante na Imagem */}
        <div className="absolute top-2 right-2 md:top-4 md:right-4 z-10">
          <span className={`text-[9px] md:text-[10px] font-black uppercase tracking-wider md:tracking-[0.15em] px-2 py-1 md:px-3 md:py-1.5 rounded-md md:rounded-lg shadow-lg backdrop-blur-md border ${
            curso.area.includes('Humanas') ? 'bg-amber-500/90 text-white border-amber-400' :
            curso.area.includes('Exatas') ? 'bg-blue-500/90 text-white border-blue-400' :
            curso.area.includes('Natureza') ? 'bg-emerald-500/90 text-white border-emerald-400' :
            'bg-indigo-500/90 text-white border-indigo-400'
          }`}>
            {curso.area}
          </span>
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>
      <div className="p-3 md:p-5 flex flex-col items-center md:items-start text-center md:text-left flex-1">
        {/* Etiqueta de Modalidade - Apenas Desktop */}
        <div className="hidden md:flex flex-col gap-2 mb-3">
          <div className="flex flex-col gap-1.5">
            <span className="text-[9px] font-black uppercase tracking-[0.2em] text-neutral-400 leading-normal">
              {mode}
            </span>
            <div className="h-0.5 w-8 bg-brand/30 rounded-full" />
          </div>
        </div>
        
        <h3 className="text-[13px] md:text-xl font-black text-neutral-900 leading-tight transition-colors uppercase tracking-tight mb-2 line-clamp-2">
          {curso.nome}
        </h3>
      </div>

      <a 
        href={`https://api.whatsapp.com/send?phone=5511950294174&text=Olá! Sou formado em ${selectedFormacao} e quero saber sobre os cursos de Licenciatura.`}
        target="_blank"
        rel="noopener noreferrer"
        className="bg-neutral-900 text-white py-3 md:py-4 px-4 md:px-8 flex items-center justify-center gap-2 md:gap-3 font-black uppercase tracking-widest text-[10px] md:text-xs transition-all hover:bg-stone-800"
      >
        Verificar disponibilidade
        <ArrowRight className="w-3 h-3 md:w-4 md:h-4" />
      </a>
    </motion.div>
  );
};
