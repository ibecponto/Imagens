import { useState, useEffect } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { banners, FALLBACK_IMAGE } from '../data/constants';

export const BannerCarousel = () => {
  const [currentBanner, setCurrentBanner] = useState(0);
  const [direction, setDirection] = useState(0);
  const [isLoaded, setIsLoaded] = useState<Record<number, boolean>>({});

  const shouldReduceMotion = useReducedMotion();

  const handleImageLoad = (index: number) => {
    setIsLoaded(prev => ({ ...prev, [index]: true }));
  };

  const paginate = (newDirection: number) => {
    setDirection(newDirection);
    setCurrentBanner((prev) => (prev + newDirection + banners.length) % banners.length);
  };

  useEffect(() => {
    if (shouldReduceMotion) return;
    const timer = setInterval(() => {
      paginate(1);
    }, 8000);
    return () => clearInterval(timer);
  }, [currentBanner, banners.length, shouldReduceMotion]);

  const bannerVariants = {
    enter: (direction: number) => ({
      x: shouldReduceMotion ? 0 : (direction > 0 ? '100%' : '-100%'),
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: shouldReduceMotion ? 0 : (direction < 0 ? '100%' : '-100%'),
      opacity: 0
    })
  };

  return (
    <div className="relative group">
      <div className="relative w-full overflow-hidden rounded-2xl md:rounded-[2rem] shadow-lg md:shadow-2xl border-4 md:border-8 border-white bg-white grid grid-cols-1 grid-rows-1">
        <AnimatePresence initial={false} custom={direction}>
          <motion.div
            key={currentBanner}
            custom={direction}
            variants={bannerVariants}
            initial="enter"
            animate="center"
            exit="exit"
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={1}
            onDragEnd={(e, { offset, velocity }) => {
              const swipe = Math.abs(offset.x) > 50 && Math.abs(velocity.x) > 500;
              if (swipe) {
                paginate(offset.x > 0 ? -1 : 1);
              }
            }}
            transition={{
              x: { type: "spring", stiffness: 300, damping: 30 },
              opacity: { duration: 0.2 }
            }}
            className="col-start-1 row-start-1 relative touch-pan-y"
          >
            <div className="relative w-full overflow-hidden">
              {/* Skeleton Shimmer */}
              {!isLoaded[currentBanner] && (
                <div className="absolute inset-0 animate-shimmer z-10" />
              )}

              <img 
                src={banners[currentBanner].image} 
                alt={`Banner ${currentBanner + 1}`} 
                width={1920}
                height={600}
                onLoad={() => handleImageLoad(currentBanner)}
                className={`w-full h-auto hidden md:block transition-opacity duration-700 ${
                  isLoaded[currentBanner] ? 'opacity-100' : 'opacity-0'
                }`}
                referrerPolicy="no-referrer"
                loading="lazy"
                onError={(e) => { 
                  e.currentTarget.src = FALLBACK_IMAGE;
                  handleImageLoad(currentBanner);
                }}
              />
              <img 
                src={banners[currentBanner].mobileImage || banners[currentBanner].image} 
                alt={`Banner ${currentBanner + 1}`} 
                width={800}
                height={704}
                onLoad={() => handleImageLoad(currentBanner)}
                className={`w-full aspect-[1/0.88] object-cover object-top block md:hidden transition-opacity duration-700 ${
                  isLoaded[currentBanner] ? 'opacity-100' : 'opacity-0'
                }`}
                referrerPolicy="no-referrer"
                loading="lazy"
                onError={(e) => { 
                  e.currentTarget.src = FALLBACK_IMAGE;
                  handleImageLoad(currentBanner);
                }}
              />

              <div className="absolute inset-0 z-20 pointer-events-none">
                {/* Mobile-only full link for square banners */}
                {banners[currentBanner].mobileImage && 
                 banners[currentBanner].mobileImage !== banners[currentBanner].image && 
                 banners[currentBanner].links.length > 0 && (
                  <a
                    href={banners[currentBanner].links[0].href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="absolute inset-0 pointer-events-auto md:hidden cursor-pointer"
                    title={banners[currentBanner].links[0].label}
                  >
                    <span className="sr-only">{banners[currentBanner].links[0].label}</span>
                  </a>
                )}

                {/* Interactive Links Overlay */}
                {banners[currentBanner].links.map((link, idx) => (
                  <a
                    key={idx}
                    href={link.href.includes('5511941622969') ? 'https://api.whatsapp.com/send?phone=5511950294174' : link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`absolute cursor-pointer pointer-events-auto z-20 hover:bg-white/10 active:bg-white/20 transition-colors rounded-lg ${
                      (banners[currentBanner].mobileImage && banners[currentBanner].mobileImage !== banners[currentBanner].image && link.width !== '100%') 
                      ? 'hidden md:block' 
                      : ''
                    }`}
                    style={{
                      top: link.top,
                      left: link.left,
                      width: link.width,
                      height: link.height
                    }}
                    title={link.label}
                  >
                    <span className="sr-only">{link.label}</span>
                  </a>
                ))}
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Navigation Arrows */}
        <button 
          onClick={() => paginate(-1)}
          className="absolute left-2 md:left-4 top-1/2 -translate-y-1/2 p-2 md:p-3 rounded-full bg-black/10 md:bg-white/90 backdrop-blur-sm md:backdrop-blur-md text-white md:text-brand shadow-sm md:shadow-xl opacity-0 md:group-hover:opacity-100 transition-all hover:bg-brand hover:text-white z-30 active:scale-90 pointer-events-none md:group-hover:pointer-events-auto"
        >
          <ChevronLeft className="w-5 h-5 md:w-6 md:h-6" />
        </button>
        <button 
          onClick={() => paginate(1)}
          className="absolute right-2 md:left-auto md:right-4 top-1/2 -translate-y-1/2 p-2 md:p-3 rounded-full bg-black/10 md:bg-white/90 backdrop-blur-sm md:backdrop-blur-md text-white md:text-brand shadow-sm md:shadow-xl opacity-0 md:group-hover:opacity-100 transition-all hover:bg-brand hover:text-white z-30 active:scale-90 pointer-events-none md:group-hover:pointer-events-auto"
        >
          <ChevronRight className="w-5 h-5 md:w-6 md:h-6" />
        </button>
      </div>

      {/* Navigation Dots */}
      <div className="flex justify-center gap-2 mt-3">
        {banners.map((_, index) => (
          <button
            key={index}
            onClick={() => {
              const newDir = index > currentBanner ? 1 : -1;
              setDirection(newDir);
              setCurrentBanner(index);
            }}
            className={`h-2 rounded-full transition-all duration-300 ${currentBanner === index ? 'bg-brand w-6' : 'bg-neutral-300 w-2 hover:bg-neutral-400'}`}
          />
        ))}
      </div>
    </div>
  );
};
