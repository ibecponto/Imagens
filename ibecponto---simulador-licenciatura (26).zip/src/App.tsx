/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Fuse from "fuse.js";
import { 
  ChevronDown,
  ArrowRight, MapPin, Search, X,
  Instagram, Facebook, Youtube, Mail, Globe, GraduationCap
} from 'lucide-react';

// Types
import { Licenciatura } from './types';

// Data
import { 
  LICENCIATURAS, 
  MAPPING, 
  PRIMEIRAS_GRADUACOES, 
  FALLBACK_IMAGE 
} from './data/constants';

// Components
import { WhatsAppIcon, GoogleIcon } from './components/Icons';
import { CourseCard } from './components/CourseCard';
import { SupportCard } from './components/SupportCard';
import { BannerCarousel } from './components/BannerCarousel';

export default function App() {
  const [selectedFormacao, setSelectedFormacao] = useState<string | null>(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [focusedIndex, setFocusedIndex] = useState(-1);
  const [scrolled, setScrolled] = useState(false);

  const dropdownRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
        setFocusedIndex(-1);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Handle scroll for header visibility
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 80);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Handle scrolling when selection changes
  useEffect(() => {
    if (selectedFormacao) {
      // Small delay to ensure the results section has rendered and started its animation
      const timer = setTimeout(() => {
        if (resultsRef.current) {
          const yOffset = -20; // Give some breathing room at the top
          const element = resultsRef.current;
          const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
          
          window.scrollTo({ top: y, behavior: 'smooth' });
        }
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [selectedFormacao]);
 
  const results = useMemo<Licenciatura[] | null>(() => {
    if (!selectedFormacao) return null;
    const ids = MAPPING[selectedFormacao] || [];
    
    // Data Integrity Check: Warning for developers if mapping points to non-existent ID
    const foundItems = ids.map(id => {
      const item = LICENCIATURAS.find(l => l.id === id);
      if (!item) {
        console.warn(`[DATA INTEGRITY] Mapping error for "${selectedFormacao}": ID "${id}" not found in LICENCIATURAS.`);
      }
      return item;
    });

    return foundItems.filter((l): l is Licenciatura => !!l);
  }, [selectedFormacao]);

  const mode = useMemo<string | null>(() => {
    if (!selectedFormacao) return null;
    if (selectedFormacao.startsWith("Bacharelado") || selectedFormacao.startsWith("Tecnologia")) {
      return "Licenciatura para Bacharéis e Tecnólogos";
    }
    return "Licenciatura para Licenciados";
  }, [selectedFormacao]);

  const normalize = (str: string) => str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

  const fuse = useMemo(() => new Fuse(PRIMEIRAS_GRADUACOES, {
    threshold: 0.4,
    distance: 100,
    ignoreLocation: true,
  }), []);

  const filteredSearch = useMemo(() => {
    if (!searchQuery.trim()) return [];
    
    // Reset focused index when results change
    setFocusedIndex(-1);
    
    const normalizedQuery = normalize(searchQuery);
    const simpleMatches = PRIMEIRAS_GRADUACOES.filter(formacao => 
      normalize(formacao).includes(normalizedQuery)
    );

    if (simpleMatches.length > 0) return simpleMatches;
    return fuse.search(searchQuery).map(result => result.item);
  }, [searchQuery, fuse]);

  return (
    <div className="min-h-screen">
      {/* Sticky Header */}
      <AnimatePresence>
        {scrolled && (
          <motion.header
            initial={{ y: -80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -80, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
            className="fixed top-0 left-0 right-0 z-[100] bg-white/90 backdrop-blur-md border-b border-stone-200 h-14 md:h-16 flex items-center justify-center px-6 shadow-sm"
          >
            <div className="w-full max-w-7xl flex items-center justify-center">
              <img 
                src="https://raw.githubusercontent.com/ibecponto/Imagens/main/logo-ibec-header.png" 
                alt="Logo IBECponto" 
                className="h-7 md:h-9 w-auto opacity-90"
              />
            </div>
          </motion.header>
        )}
      </AnimatePresence>

      {/* WhatsApp Float */}
      <a 
        href="https://api.whatsapp.com/send?phone=5511950294174&text=Olá! Gostaria de tirar algumas dúvidas sobre os cursos de Licenciatura." 
        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-10 right-4 md:bottom-12 md:right-8 z-[60] bg-[#25D366] text-white p-2.5 md:p-4 rounded-full shadow-2xl hover:scale-110 active:scale-90 transition-all flex items-center justify-center animate-bounce-subtle"
        title="Falar com Consultor"
        aria-label="Conversar com consultor no WhatsApp"
      >
        <WhatsAppIcon className="w-7 h-7 md:w-8 md:h-8 fill-white" />
      </a>

      {/* Hero Section */}
      <section className="relative flex items-center justify-center min-h-[260px] md:min-h-[320px] lg:min-h-[350px] xl:min-h-[380px] pt-6 md:pt-8 lg:pt-10 pb-8 md:pb-10 lg:pb-12 overflow-hidden">
        <div className="absolute inset-0 z-0 bg-stone-100">
            <img 
              src="https://raw.githubusercontent.com/ibecponto/Imagens/main/herolicenciatura.png" 
              alt="Segunda Licenciatura" 
              width={1920}
              height={600}
              className="w-full h-full object-cover object-center sepia-[0.3] opacity-[0.35] brightness-100 contrast-105 blur-[1px]"
              referrerPolicy="no-referrer"
              onError={(e) => { e.currentTarget.src = FALLBACK_IMAGE; }}
            />
          <div className="absolute inset-0 bg-gradient-to-b from-orange-50/40 via-stone-100/30 to-stone-200/60"></div>
        </div>

        <div className="relative z-10 w-full max-w-7xl mx-auto px-6 md:px-8">
          <div className="max-w-5xl mx-auto w-full">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col items-center text-center gap-4 md:gap-5 w-full pt-10"
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.1 }}
                className="transition-all duration-300 mb-4 md:mb-6"
              >
                <div className="w-[140px] md:w-[200px] mx-auto opacity-90 relative left-[2px] md:left-[4px]">
                  <img 
                    src="https://raw.githubusercontent.com/ibecponto/Imagens/main/logo-ibec-header.png" 
                    alt="Logo IBECponto" 
                    width={200}
                    height={60}
                    className="w-full h-auto object-contain"
                    referrerPolicy="no-referrer"
                    onError={(e) => { e.currentTarget.src = FALLBACK_IMAGE; }}
                  />
                </div>
              </motion.div>

              <div className="flex flex-col items-center text-center gap-3 md:gap-4 relative left-[2px] md:left-[4px]">
                <h1 className="flex flex-col items-center font-black font-headline leading-[1] tracking-tight drop-shadow-[0_4px_12px_rgba(0,0,0,0.08)]">
                  <span className="text-stone-800 text-[1.4rem] md:text-[2.6rem] lg:text-[2.8rem] mb-1">Conquiste sua</span>
                  <span className="text-brand text-[1.9rem] md:text-[3.2rem] lg:text-[3.4rem] uppercase">Licenciatura</span>
                </h1>
                <p className="text-[0.75rem] md:text-[0.8rem] font-black text-stone-700 uppercase tracking-[0.2em] max-w-[280px] md:max-w-none">
                  Para licenciados · bacharéis · tecnólogos
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Course Selector */}
      <motion.section 
        layout
        className={`relative z-20 -mt-2 md:-mt-4 mx-auto px-4 md:px-6 w-full transition-all duration-500 ease-[cubic-bezier(0.22,1,0.36,1)] ${
          selectedFormacao 
            ? 'max-w-7xl' 
            : 'max-w-5xl'
        }`}
      >
        <div className="bg-white p-5 md:p-7 rounded-2xl shadow-[0_32px_64px_-12px_rgba(0,0,0,0.12)] border border-stone-200/50 border-b-8 border-b-stone-800 flex flex-col items-center text-center gap-6">
          <div className="w-full space-y-7 md:space-y-6">
            <label 
              id="dropdown-label"
              className="block text-base md:text-lg lg:text-[1.15rem] font-bold text-stone-800 tracking-tight ml-1 leading-tight text-balance"
            >
              Digite sua <span className="text-stone-900 border-b-2 border-brand uppercase">primeira formação</span> e saiba quais os cursos ideais para você
            </label>
            <div 
              className="relative max-w-2xl mx-auto" 
              ref={dropdownRef}
              role="combobox"
              aria-expanded={isDropdownOpen}
              aria-haspopup="listbox"
              aria-controls="dropdown-list"
            >
              <div className="relative group">
                <input 
                  ref={inputRef}
                  type="text"
                  placeholder="Digite"
                  value={isDropdownOpen ? (searchQuery || selectedFormacao || "") : (selectedFormacao || searchQuery || "")}
                  aria-autocomplete="list"
                  aria-labelledby="dropdown-label"
                  aria-activedescendant={focusedIndex >= 0 ? `option-${focusedIndex}` : undefined}
                  onKeyDown={(e) => {
                    if (e.key === 'Backspace' && searchQuery === "") {
                      setIsDropdownOpen(false);
                      setSelectedFormacao(null);
                    }
                    
                    if (!isDropdownOpen && filteredSearch.length > 0 && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
                      setIsDropdownOpen(true);
                      return;
                    }

                    if (isDropdownOpen && filteredSearch.length > 0) {
                      if (e.key === 'ArrowDown') {
                        e.preventDefault();
                        setFocusedIndex(prev => (prev + 1) % filteredSearch.length);
                      } else if (e.key === 'ArrowUp') {
                        e.preventDefault();
                        setFocusedIndex(prev => (prev - 1 + filteredSearch.length) % filteredSearch.length);
                      } else if (e.key === 'Enter' && focusedIndex >= 0) {
                        e.preventDefault();
                        const formacao = filteredSearch[focusedIndex];
                        setSelectedFormacao(formacao);
                        setSearchQuery(formacao);
                        setIsDropdownOpen(false);
                        setFocusedIndex(-1);
                      } else if (e.key === 'Escape') {
                        setIsDropdownOpen(false);
                        setFocusedIndex(-1);
                      }
                    }
                  }}
                  onChange={(e) => {
                    const val = e.target.value;
                    setSearchQuery(val);
                    
                    // Se o usuário apagar tudo ou digitar algo diferente da formação selecionada, limpa a seleção
                    if (val === "" || val !== selectedFormacao) {
                      setSelectedFormacao(null);
                    }

                    if (val === "") {
                      setIsDropdownOpen(false);
                    } else if (!isDropdownOpen) {
                      setIsDropdownOpen(true);
                    }
                  }}
                  className="w-full bg-neutral-50 border-2 border-neutral-200 rounded-xl py-4 md:py-5 px-4 md:px-7 text-on-surface focus:ring-8 focus:ring-brand/5 focus:border-brand transition-all cursor-pointer font-black text-sm md:text-xl pr-24 md:pr-24 outline-none shadow-sm hover:border-brand/30"
                />
                <div className="absolute right-3 md:right-6 top-1/2 -translate-y-1/2 flex items-center gap-1.5 md:gap-3">
                  {(searchQuery || selectedFormacao) && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSearchQuery("");
                        setSelectedFormacao(null);
                        setIsDropdownOpen(false);
                        setFocusedIndex(-1);
                        inputRef.current?.focus();
                      }}
                      className="p-1 hover:bg-neutral-200 rounded-full transition-colors pointer-events-auto"
                    >
                      <X className="w-4 h-4 md:w-5 md:h-5 text-neutral-400" />
                    </button>
                  )}
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      const nextState = !isDropdownOpen;
                      setIsDropdownOpen(nextState);
                      if (!nextState) setFocusedIndex(-1);
                    }}
                    className="flex items-center gap-1.5 md:gap-3 p-1 hover:bg-neutral-200 rounded-lg transition-colors pointer-events-auto"
                  >
                    <Search className="w-5 h-5 text-brand" />
                    <ChevronDown className={`w-5 h-5 text-neutral-400 transition-transform duration-300 ${isDropdownOpen ? 'rotate-180' : ''}`} />
                  </button>
                </div>
              </div>

              <AnimatePresence>
                {isDropdownOpen && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="relative mt-3 bg-white rounded-2xl shadow-[0_10px_30px_rgba(0,0,0,0.08)] border border-neutral-100 overflow-hidden z-50"
                  >
                    <div id="dropdown-list" role="listbox" className="max-h-96 md:max-h-[450px] overflow-y-auto">
                      {filteredSearch.length > 0 ? (
                        filteredSearch.map((formacao, index) => (
                          <div 
                            key={formacao}
                            id={`option-${index}`}
                            role="option"
                            aria-selected={selectedFormacao === formacao || focusedIndex === index}
                            onClick={() => {
                              setSelectedFormacao(formacao);
                              setSearchQuery(formacao);
                              setIsDropdownOpen(false);
                              setFocusedIndex(-1);
                            }}
                            className={`px-6 py-3 md:px-8 md:py-3.5 cursor-pointer transition-colors font-bold text-neutral-700 flex items-center justify-between group border-b border-neutral-50 last:border-none gap-4 ${
                              focusedIndex === index ? 'bg-brand/10' : 'hover:bg-brand/5'
                            }`}
                          >
                            <span className="flex items-center flex-1">
                              <span className="flex-1 leading-tight">{formacao}</span>
                            </span>
                            <ArrowRight className="flex-shrink-0 w-5 h-5 opacity-0 md:group-hover:opacity-100 group-hover:translate-x-1 transition-all text-brand" />
                          </div>
                        ))
                      ) : (
                        <div 
                          className="p-8 text-center bg-white"
                          onClick={() => {
                            window.open(`https://api.whatsapp.com/send?phone=5511950294174&text=Olá! Gostaria de tirar algumas dúvidas sobre os cursos de Licenciatura.`, '_blank');
                          }}
                        >
                          <div className="w-16 h-16 bg-brand/5 rounded-full flex items-center justify-center mx-auto mb-5 border border-brand/10">
                            <GraduationCap className="w-8 h-8 text-brand/40" />
                          </div>
                          <p className="font-black text-neutral-900 mb-2 uppercase tracking-tight">Não encontrou sua formação?</p>
                          <p className="text-[13px] text-neutral-500 mb-8 px-4 leading-relaxed font-bold">
                            Fale com a nossa equipe e encontre o melhor caminho
                          </p>
                          <div className="inline-flex items-center gap-2 bg-[#25D366] text-white px-8 py-4 rounded-xl font-black text-[11px] uppercase tracking-widest hover:bg-[#128c7e] transition-all cursor-pointer shadow-lg shadow-[#25D366]/20">
                            <WhatsAppIcon className="w-4 h-4 fill-current" />
                            Falar com Consultor
                          </div>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </motion.section>

      {/* Featured Courses (Results) */}
      <AnimatePresence mode="wait">
        {selectedFormacao && (
          <motion.section 
            key={selectedFormacao}
            ref={resultsRef}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -30 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className="py-10 md:py-16 bg-surface-container-low"
          >
            <div className="max-w-6xl mx-auto px-6">
              <div className="flex flex-col md:flex-row justify-between items-end mb-6 md:mb-12 gap-6">
                <div>
                  <h2 className="text-[1.5rem] md:text-[1.8rem] font-black tracking-tight uppercase leading-tight">
                    {mode}
                  </h2>
                  <div className="h-1.5 w-16 bg-brand rounded-full mt-4 mb-6"></div>
                  <p className="text-neutral-600 text-lg max-w-2xl leading-relaxed flex flex-wrap items-center gap-x-2 gap-y-1">
                    Opções ideais para quem é graduado em: 
                    <span className="font-bold text-brand">{selectedFormacao}</span>
                    <button 
                      onClick={() => {
                        setSelectedFormacao(null);
                        setSearchQuery("");
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                        inputRef.current?.focus();
                      }}
                      className="inline-flex items-center gap-1.5 text-[10px] uppercase tracking-widest font-black text-neutral-400 hover:text-brand transition-colors ml-2 bg-neutral-100 hover:bg-brand/5 px-2.5 py-1 rounded-full border border-neutral-200 hover:border-brand/20 group"
                    >
                      <X className="w-3 h-3 group-hover:rotate-90 transition-transform" />
                      Trocar
                    </button>
                  </p>
                </div>
              </div>

              {results && results.length > 0 ? (
                <div key={selectedFormacao} className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-5 items-stretch">
                  {(results as Licenciatura[]).map((curso: Licenciatura, index: number) => (
                    <CourseCard 
                      key={curso.id} 
                      curso={curso} 
                      index={index} 
                      mode={mode} 
                      selectedFormacao={selectedFormacao} 
                    />
                  ))}
                  <SupportCard index={results.length} selectedFormacao={selectedFormacao} />
                </div>
              ) : (
                <div className="bg-white p-8 rounded-[2rem] border border-stone-200 text-center max-w-md mx-auto shadow-xl shadow-stone-200/50">
                  <div className="w-16 h-16 bg-brand/5 rounded-full flex items-center justify-center mx-auto mb-6 border border-brand/10">
                    <GraduationCap className="w-8 h-8 text-brand" />
                  </div>
                  <h3 className="text-xl font-black text-neutral-900 mb-4 uppercase tracking-tight leading-tight">
                    Análise de Perfil Especial
                  </h3>
                  <p className="text-neutral-600 leading-relaxed text-base mb-8">
                    Para o seu perfil de formação, as normas vigentes do <span className="font-bold text-brand italic">CNE/MEC (Portaria 381/2025)</span> exigem uma <span className="font-bold text-brand">validação individualizada</span> do seu histórico acadêmico para garantir o melhor aproveitamento.
                  </p>
                  <a 
                    href={`https://api.whatsapp.com/send?phone=5511950294174&text=Olá! Sou formado em ${selectedFormacao} e quero saber sobre os cursos de Licenciatura.`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex py-4 px-10 rounded-xl bg-[#25D366] text-white text-[10px] font-black uppercase tracking-widest hover:bg-[#128c7e] transition-all items-center gap-4 shadow-2xl shadow-[#25D366]/10 active:scale-95"
                  >
                    <WhatsAppIcon className="w-5 h-5 fill-current" />
                    Solicitar Minha Rota Agora
                  </a>
                </div>
              )}

              {/* Public Legal Disclaimer */}
              {results && results.length > 0 && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="mt-8 p-6 bg-stone-50 rounded-2xl border border-stone-200 max-w-4xl mx-auto text-center"
                >
                  <p className="text-[10px] md:text-[11px] text-stone-500 leading-relaxed font-bold uppercase tracking-wider">
                    <span className="text-brand font-black">Observação:</span> Estes resultados são sugestões baseadas na sua área. Verifique a melhor opção com o consultor.
                  </p>
                </motion.div>
              )}
            </div>
          </motion.section>
        )}
      </AnimatePresence>

      <section className="pt-4 md:pt-6 lg:pt-10 pb-12 md:pb-20">
        <div className="max-w-4xl mx-auto px-4 md:px-6">
          <BannerCarousel />
        </div>
      </section>

      <footer className="bg-neutral-950 text-white pt-8 md:pt-10 pb-32 md:pb-16">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-[1.4fr_0.8fr_1.1fr_1fr] gap-8 lg:gap-10 mb-8 md:mb-6 items-start">
            <div className="flex items-center gap-3 md:gap-3">
              <div className="w-10 h-10 md:w-11 md:h-11 rounded-full bg-neutral-900 flex items-center justify-center flex-shrink-0 text-brand">
                <MapPin className="w-5 h-5 text-brand" />
              </div>
              <div>
                <p className="text-[11px] md:text-[11px] uppercase tracking-widest text-neutral-200 font-bold mb-0.5">Coworking</p>
                <p className="text-xs md:text-[13.2px] font-normal text-neutral-500 leading-tight">
                  Av. Eng. Luiz Carlos Berrini, 1681,<br className="hidden md:block" /> Sala 112 - Ed. Berrini - Itaim Bibi - SP
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3 md:gap-3">
              <div className="w-10 h-10 md:w-11 md:h-11 rounded-full bg-neutral-900 flex items-center justify-center flex-shrink-0">
                <Mail className="w-5 h-5 text-brand" />
              </div>
              <div>
                <p className="text-[11px] md:text-[11px] uppercase tracking-widest text-neutral-200 font-bold mb-0.5">E-mail</p>
                <p className="text-xs md:text-[13.2px] font-normal text-neutral-500">contato@ibecponto.com.br</p>
              </div>
            </div>
            <div className="flex items-center gap-3 md:gap-3">
              <div className="w-10 h-10 md:w-11 md:h-11 rounded-full bg-neutral-900 flex items-center justify-center flex-shrink-0">
                <WhatsAppIcon className="w-5 h-5 fill-brand" />
              </div>
              <div>
                <p className="text-[11px] md:text-[11px] uppercase tracking-widest text-neutral-200 font-bold mb-0.5">WhatsApp Central</p>
                <a href="https://api.whatsapp.com/send?phone=5511941622969" target="_blank" rel="noopener noreferrer" className="text-xs md:text-[13.2px] font-normal text-neutral-500 hover:text-brand transition-colors">(11) 941622969</a>
              </div>
            </div>
            <div className="flex items-center gap-3 md:gap-3">
              <div className="w-10 h-10 md:w-11 md:h-11 rounded-full bg-neutral-900 flex items-center justify-center flex-shrink-0">
                <Globe className="w-5 h-5 text-brand" />
              </div>
              <div>
                <p className="text-[11px] md:text-[11px] uppercase tracking-widest text-neutral-200 font-bold mb-0.5">Site Oficial</p>
                <a href="https://www.ibecponto.com.br" target="_blank" rel="noopener noreferrer" className="text-xs md:text-[13.2px] font-normal text-neutral-500 hover:text-brand transition-colors">www.ibecponto.com.br</a>
              </div>
            </div>
            <div className="sm:col-span-2 lg:col-span-4 flex flex-col items-center justify-center mt-4 sm:mt-6 md:mt-4">
              <p className="text-[11px] md:text-[11px] uppercase tracking-widest text-neutral-200 font-bold mb-4">Redes Sociais</p>
              <div className="flex gap-4">
                <a href="https://www.instagram.com/ibecponto/" target="_blank" rel="noopener noreferrer" className="w-[42px] h-[42px] rounded-full bg-neutral-900 flex items-center justify-center hover:bg-brand transition-colors group" title="Instagram">
                  <Instagram className="w-[20px] h-[20px] text-neutral-500 group-hover:text-white transition-colors" />
                </a>
                <a href="https://web.facebook.com/ibecponto.com.br/?_rdc=1&_rdr#" target="_blank" rel="noopener noreferrer" className="w-[42px] h-[42px] rounded-full bg-neutral-900 flex items-center justify-center hover:bg-brand transition-colors group" title="Facebook">
                  <Facebook className="w-[20px] h-[20px] text-neutral-500 group-hover:text-white transition-colors" />
                </a>
                <a href="https://www.youtube.com/channel/UCTWPiXm3Dcy5Y4-QXWqm-Dw" target="_blank" rel="noopener noreferrer" className="w-[42px] h-[42px] rounded-full bg-neutral-900 flex items-center justify-center hover:bg-brand transition-colors group" title="YouTube">
                  <Youtube className="w-[20px] h-[20px] text-neutral-500 group-hover:text-white transition-colors" />
                </a>
                <a href="https://www.google.com/search?q=ibecponto" target="_blank" rel="noopener noreferrer" className="w-[42px] h-[42px] rounded-full bg-neutral-900 flex items-center justify-center hover:bg-brand transition-colors group" title="Google">
                  <div className="grayscale opacity-60 group-hover:grayscale-0 group-hover:opacity-100 transition-all flex items-center justify-center">
                    <GoogleIcon className="w-[20px] h-[20px]" />
                  </div>
                </a>
              </div>
            </div>
          </div>
          <div className="pt-6 border-t border-white/5 flex flex-col lg:flex-row justify-between items-center gap-4 lg:gap-4 text-center lg:text-left overflow-hidden">
            <p className="text-[11px] md:text-[11px] uppercase tracking-widest text-neutral-500 font-medium md:whitespace-nowrap">
              © 2026 IBECponto Educação Continuada <br className="md:hidden" /> Todos os direitos reservados. <br className="md:hidden" /> CNPJ: 40.671.041/0001-24
            </p>
            <p className="text-[11px] md:text-[11px] uppercase tracking-widest text-neutral-500 font-medium flex flex-col sm:flex-row items-center gap-1 sm:gap-2 md:whitespace-nowrap">
              <span>Desenvolvido por</span>
              <a href="https://www.bcktecnologia.com.br" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-400 transition-colors font-black">BCK Tecnologia</a>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
